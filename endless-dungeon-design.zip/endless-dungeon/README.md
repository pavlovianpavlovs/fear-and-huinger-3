# The Endless Dungeon

A solo crossover mod concept for Fear & Hunger 2: Termina (primary host) and Fear & Hunger (required companion). Termina remains the game the player launches. The mod must read content from each player's own installation and must not redistribute either game's assets.

## First playable scope
- One short, repeatable dungeon excursion entered from a dedicated test trigger.
- Termina remains the host and supplies the player character, movement, combat loop, and save context.
- Fear & Hunger contributes a small, explicitly mapped set of real enemy/item/map definitions loaded from the companion install at runtime; no copied game assets in the package.
- Solo only.
- A visible diagnostic/test mode confirms the companion path was found and reports which mapped content entries were loaded.

## Current status
Design sheets only. No gameplay build or in-game test has been completed. Runtime integration depends on inspecting the user's installed game folders and the Melty recipe/tooling.
